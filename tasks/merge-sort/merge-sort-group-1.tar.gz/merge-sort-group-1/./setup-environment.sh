export CXX=icpx
export FLAGS_OPENMP=-qopenmp
